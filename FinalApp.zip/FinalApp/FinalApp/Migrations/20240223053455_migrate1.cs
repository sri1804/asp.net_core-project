﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FinalApp.Migrations
{
    public partial class migrate1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserLanguages_Users_UsersId",
                table: "UserLanguages");

            migrationBuilder.DropIndex(
                name: "IX_UserLanguages_UsersId",
                table: "UserLanguages");

            migrationBuilder.DropColumn(
                name: "UsersId",
                table: "UserLanguages");

            migrationBuilder.CreateIndex(
                name: "IX_UserLanguages_userId",
                table: "UserLanguages",
                column: "userId");

            migrationBuilder.AddForeignKey(
                name: "FK_UserLanguages_Users_userId",
                table: "UserLanguages",
                column: "userId",
                principalTable: "Users",
                principalColumn: "Id",
                 onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserLanguages_Users_userId",
                table: "UserLanguages");

            migrationBuilder.DropIndex(
                name: "IX_UserLanguages_userId",
                table: "UserLanguages");

            migrationBuilder.AddColumn<int>(
                name: "UsersId",
                table: "UserLanguages",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserLanguages_UsersId",
                table: "UserLanguages",
                column: "UsersId");

            migrationBuilder.AddForeignKey(
                name: "FK_UserLanguages_Users_UsersId",
                table: "UserLanguages",
                column: "UsersId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
