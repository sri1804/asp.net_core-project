﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FinalApp.DB;
using FinalApp.Models;

namespace FinalApp.Controllers
{
    public class CityController : Controller
    {
        private readonly MyDb _context;

        public CityController(MyDb context)
        {
            _context = context;
        }

      
        public async Task<IActionResult> Index()
        {
            var myDb = _context.Cities.Include(c => c.state);
            return View(await myDb.ToListAsync());
        }

        
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var city = await _context.Cities
                .Include(c => c.state)
                .FirstOrDefaultAsync(m => m.cityId == id);
            if (city == null)
            {
                return NotFound();
            }

            return View(city);
        }

    
        public IActionResult Create()
        {
            ViewData["stateId"] = new SelectList(_context.States, "Id", "Id");
            return View();
        }
        [HttpPost]
       
        public async Task<IActionResult> Create([Bind("cityId,cityName,stateId")] City city)
        {
            if (ModelState.IsValid)
            {
                _context.Add(city);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["stateId"] = new SelectList(_context.States, "Id", "Id", city.stateId);
            return View(city);
        }
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var city = await _context.Cities.FindAsync(id);
            if (city == null)
            {
                return NotFound();
            }
            ViewData["stateId"] = new SelectList(_context.States, "Id", "Id", city.stateId);
            return View(city);
        }

        [HttpPost]
        
        public async Task<IActionResult> Edit(int id, [Bind("cityId,cityName,stateId")] City city)
        {
            if (id != city.cityId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(city);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CityExists(city.cityId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["stateId"] = new SelectList(_context.States, "Id", "Id", city.stateId);
            return View(city);
        }

     
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var city = await _context.Cities
                .Include(c => c.state)
                .FirstOrDefaultAsync(m => m.cityId == id);
            if (city == null)
            {
                return NotFound();
            }

            return View(city);
        }

        // POST: City/Delete/5
        [HttpPost, ActionName("Delete")]
        
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var city = await _context.Cities.FindAsync(id);
            _context.Cities.Remove(city);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult GetCitiesByState(int stateId)
        {
            var cities = _context.Cities.Where(c => c.stateId == stateId).ToList();
            return PartialView("_CityDropdown", cities);
        }

        private bool CityExists(int id)
        {
            return _context.Cities.Any(e => e.cityId == id);
        }
    }
}
