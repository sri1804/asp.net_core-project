﻿using FinalApp.DB;
using FinalApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;


namespace FinalApp.Controllers
{
    public class UserController : Controller
    {
        private readonly MyDb _context;
        public UserController(MyDb context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var users = _context.Users.ToList();
            return View(users);
        }
        [HttpGet]
        public IActionResult Create()
        {
            LoadLanguages();
            LoadGender();
            LoadEducation();
            LoadCity();
            LoadState();
            LoadHobby();
            return View();
        }
        [NonAction]
        private void LoadLanguages(){
            var languages = _context.Languages.ToList();
            ViewBag.Languages = languages;
        }
        [NonAction]
        private void LoadGender(){
            var g = _context.Genders.ToList();
            ViewBag.Genders = g;
        }
        [NonAction]
        private void LoadEducation(){
            var educ = _context.Educations.ToList();
            ViewBag.edus = new SelectList(educ, "Id", "Edu");
        }
        [NonAction]
        private void LoadCity(){
            var c = _context.Cities.ToList();
            ViewBag.city = new SelectList(c, "cityId","cityName");
        }
        [NonAction]
        private void LoadState(){
            var s = _context.States.ToList();
            ViewBag.States = new SelectList(s,"Id","stateName");
        }
        private void LoadHobby(){
            var h = _context.Hobbies.ToList();
            ViewBag.Hobbies = new SelectList(h, "Id", "hob"); ;
        }

        [HttpPost]
        public IActionResult Create(Users model, string[] selectedLanguages, string[] selectedHobbies)
        {
            if (ModelState.IsValid)
            {
                model.FullName = model.FirstName + " " + model.LastName;
                _context.Users.Add(model);
                _context.SaveChanges(); 

                model.UserLanguage = new List<UserLanguage>();
                if (selectedLanguages != null)
                {
                    foreach (var langId in selectedLanguages)
                    {
                        var productLanguage = new UserLanguage { userId = model.Id, LangId = langId };
                        model.UserLanguage.Add(productLanguage);
                        _context.UserLanguages.Add(productLanguage);
                    }
                    _context.SaveChanges(); 
                }

                if (selectedHobbies != null)
                {
                    foreach (var hobbId in selectedHobbies)
                    {
                        var hobbyIds = hobbId.Split(',');
                        foreach (var hobbyId in hobbyIds)
                        {
                            var userHobby = new UserHobby { userId = model.Id, hobbyId = hobbyId };
                            model.UserHobby ??= new List<UserHobby>(); 
                            model.UserHobby.Add(userHobby);
                            _context.UserHobbies.Add(userHobby);
                        }
                    }
                    _context.SaveChanges(); 
                }

                return RedirectToAction(nameof(Index));
            }
            
            LoadLanguages();
            LoadGender();
            LoadEducation();
            LoadCity();
            LoadState();
            LoadHobby();
           
            return View(model);
        }

        [HttpGet]
        public IActionResult Edit(int? id)
        {
            LoadEducation();
            LoadGender();
            LoadCity();
            LoadHobby();
            LoadState();
            LoadLanguages();

            if (id == null)
            {
                return NotFound();
            }

            var user = _context.Users.Include(u => u.UserHobby).FirstOrDefault(u => u.Id == id);
            string[] names = user.FullName.Split(' ');
            user.FirstName = names[0];
            user.LastName = names[1];

            if (user == null)
            {
                return NotFound();
            }

            ViewBag.Hobbies = _context.Hobbies.Select(h => new SelectListItem { Value = h.Id.ToString(), Text = h.hob }).ToList();
            var selectedHobbyIds = user?.UserHobby?.Select(uh => uh.hobbyId).ToList();
            ViewBag.SelectedHobbyIds = selectedHobbyIds ?? new List<string>();
            return View(user);
        }

        [HttpPost]
        public IActionResult Edit(Users model, string[] selectedLanguages, string selectedHobbies)
        {
            if (ModelState.IsValid)
            {
                var userToUpdate = _context.Users
                    .Include(u => u.UserLanguage)
                    .Include(u => u.UserHobby)
                    .FirstOrDefault(u => u.Id == model.Id);

                if (userToUpdate == null)
                {
                    return NotFound();
                }

                userToUpdate.FullName = model.FirstName+" "+ model.LastName;
                //userToUpdate.LastName = model.LastName;
                userToUpdate.Phone = model.Phone;
                userToUpdate.Email = model.Email;
                userToUpdate.GenderId = model.GenderId;
                userToUpdate.ediId = model.ediId;
                userToUpdate.Address = model.Address;
                userToUpdate.StateId = model.StateId;
                userToUpdate.CityId = model.CityId;

                if (selectedLanguages != null)
                {
                    userToUpdate.UserLanguage.Clear();

                    foreach (var langId in selectedLanguages)
                    {
                        if (_context.Languages.Any(l => l.Id == langId))
                        {
                            var newUserLanguage = new UserLanguage { userId = userToUpdate.Id, LangId = langId };
                            userToUpdate.UserLanguage.Add(newUserLanguage);
                        }
                    }
                }
                userToUpdate.UserHobby.Clear();
                if (!string.IsNullOrEmpty(selectedHobbies))
                {
                    var hobbyIds = selectedHobbies.Split(',');

                    foreach (var hobbyId in hobbyIds)
                    {
                        if (_context.Hobbies.Any(h => h.Id == hobbyId))
                        {
                            var newUserHobby = new UserHobby { userId = userToUpdate.Id, hobbyId = hobbyId };
                            userToUpdate.UserHobby.Add(newUserHobby);
                        }
                    }
                }
                _context.SaveChanges();  
                return RedirectToAction(nameof(Index));
            }
            LoadLanguages();
            LoadGender();
            LoadEducation();
            LoadCity();
            LoadState();
            LoadHobby();

            return View(model);
        }
    
        [HttpGet]
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                NotFound();
            }
            var p = _context.Users.Find(id);
            if (p == null)
                return NotFound(); 
            string[] names = p.FullName.Split(' ');
            p.FirstName = names[0];
            p.LastName = names[1];
            LoadEducation();
            LoadGender();
            LoadCity();
            LoadHobby();
            LoadState();
            LoadLanguages();
            
            return View(p);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult Deleteconfirm(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null)
            {
                return NotFound();
            }
            var relatedUserLanguages = _context.UserLanguages.Where(ul => ul.userId == id);
            _context.UserLanguages.RemoveRange(relatedUserLanguages);
            _context.Users.Remove(user);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
    }
}
