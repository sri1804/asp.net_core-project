﻿using FinalApp.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApp.DB
{
    public class MyDb : DbContext
    {
        public MyDb(DbContextOptions<MyDb> options) : base(options)
        {

        }
        public virtual DbSet<Education> Educations { get; set; }
        public virtual DbSet<Gender> Genders { get; set; }
        public virtual DbSet<Users> Users { get; set; }
        public virtual DbSet<City> Cities { get; set; }
        public virtual DbSet<State> States { get; set; }
        public virtual DbSet<Hobby> Hobbies { get; set; }
        public virtual DbSet<UserHobby> UserHobbies { get; set; }
        public virtual DbSet<Language> Languages { get; set; }
        public virtual DbSet<UserLanguage> UserLanguages { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Users>()
                .HasOne(u => u.State)
                .WithMany()
                .HasForeignKey(u => u.StateId)
                .OnDelete(DeleteBehavior.ClientSetNull);

            modelBuilder.Entity<UserLanguage>()
        .HasOne(ul => ul.user)
        .WithMany(u => u.UserLanguage)
        .HasForeignKey(ul => ul.userId)
        .OnDelete(DeleteBehavior.Cascade);

        }

    }
}
