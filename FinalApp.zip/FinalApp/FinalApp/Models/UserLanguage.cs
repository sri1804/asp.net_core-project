﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApp.Models
{
    public class UserLanguage
    {
        [Key]
        public int Id { get; set; }
       
        public int userId { get; set; }
        [ForeignKey("user")]
        [NotMapped]
        public virtual Users user { get; set; }

        [ForeignKey("language")]
        public string LangId { get; set; }
        public virtual Language language { get; set; }
    }
}
