﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApp.Models
{
    public class City
    {
        [Key]
        public int cityId { get; set; }
        [DisplayName("City")]
        public string cityName { get; set; }

        [ForeignKey("state")]
        public int stateId { get; set; }
        public virtual State state { get; set; }
    }
}
