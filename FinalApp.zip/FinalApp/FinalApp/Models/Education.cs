﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApp.Models
{
    public class Education
    {
        [Key]
        public int Id { get; set; }

        [DisplayName("Education")]
        public string Edu { get; set; }
    }
}
