﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApp.Models
{
    public class Users
    {
        public Users()
        {
            UserLanguage = new List<UserLanguage>();
            UserHobby = new List<UserHobby>();
        }

        [Key]
        public int Id { get; set; }

        [NotMapped]
        [Required(ErrorMessage ="First name is required")]
        [RegularExpression(@"^[A-Za-z]+$",ErrorMessage ="Should start only with capital")]
        [DisplayName("First Name")]
        public string FirstName { get; set; }

        [NotMapped]
        [Required(ErrorMessage = "Last name is required")]
        [RegularExpression(@"^[A-Za-z]+$", ErrorMessage = "Should start only with capital")]
        [DisplayName("Last Name")]
        public string LastName { get; set; }

        [DisplayName("Employee name")]
        public string FullName { get; set; }

        [Required(ErrorMessage ="Phone number is required")]
        [RegularExpression(@"^[6-9]\d{9}$",ErrorMessage ="Invalid phone format-should start with numbers between 6-9")]
        [StringLength(10,MinimumLength =10, ErrorMessage ="Phone number must be atleast 10 digits long")]
        public string Phone { get; set; }

        [Required(ErrorMessage ="email is required")]
        [DataType(DataType.EmailAddress, ErrorMessage ="invalid email")]
        public string Email { get; set; }

        [Required]
        [DisplayName("Gender")]
        [ForeignKey("Gender")]
        public int? GenderId { get; set; }
        public virtual Gender Gender { get; set; }

        [Required]
        [DisplayName("Education")]
        [ForeignKey("edus")]
        public int? ediId { get; set; }
        public virtual Education edus { get; set; }

        public string Address { get; set; }

        [Required]
        [DisplayName("State")]
        [ForeignKey("State")]
        public int? StateId { get; set; }
        public virtual State State { get; set; }

        [Required]

        [DisplayName("City")]
        [ForeignKey("City")]
        public int? CityId { get; set; }
        public virtual City City { get; set; }

        [DisplayName("Hobbies")]
        public virtual ICollection<UserHobby> UserHobby { get; set; }
        [DisplayName("Languages Known")]
        public virtual ICollection<UserLanguage> UserLanguage { get; set; }
    }
}
    