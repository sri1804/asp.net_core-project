﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApp.Models
{
    public class UserHobby
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("user")]
        public int userId { get; set; }
        public virtual Users user { get; set; }

        [ForeignKey("hobby")]
        public string hobbyId { get; set; }
        public virtual Hobby hobby { get; set; }
    }
}
